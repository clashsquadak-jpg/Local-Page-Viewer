package com.localpage.viewer

import android.app.Activity
import android.content.Context
import android.content.pm.ActivityInfo

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("settings", Context.MODE_PRIVATE)

    // 0 = auto (follow device), 1 = portrait, 2 = landscape
    fun orientation(c: Context) = p(c).getInt("orientation", 0)
    fun setOrientation(c: Context, v: Int) = p(c).edit().putInt("orientation", v).apply()

    fun autoOpen(c: Context) = p(c).getBoolean("autoOpen", true)
    fun keepOn(c: Context) = p(c).getBoolean("keepOn", false)
    fun hideStatusPortrait(c: Context) = p(c).getBoolean("hideStatusPortrait", false)
    fun setBool(c: Context, key: String, v: Boolean) = p(c).edit().putBoolean(key, v).apply()

    fun apply(a: Activity) {
        a.requestedOrientation = when (orientation(a)) {
            1 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_PORTRAIT
            2 -> ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            else -> ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
    }
}
