package com.localpage.viewer

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun header(t: String): TextView {
        val h = TextView(this)
        h.text = t
        h.textSize = 13f
        h.setTextColor(Color.parseColor("#7C9CFF"))
        h.setTypeface(h.typeface, Typeface.BOLD)
        h.setPadding(0, dp(24), 0, dp(8))
        return h
    }

    private fun note(t: String): TextView {
        val n = TextView(this)
        n.text = t
        n.textSize = 12f
        n.setTextColor(Color.parseColor("#9E9E9E"))
        n.setPadding(0, dp(2), 0, dp(4))
        return n
    }

    private fun toggle(label: String, desc: String, key: String, value: Boolean): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, dp(8), 0, dp(8))
        val s = Switch(this)
        s.text = label
        s.textSize = 16f
        s.setTextColor(Color.WHITE)
        s.isChecked = value
        s.setOnCheckedChangeListener { _, b -> Prefs.setBool(this, key, b) }
        box.addView(s)
        box.addView(note(desc))
        return box
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.apply(this)

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(20), dp(16), dp(20), dp(32))

        val title = TextView(this)
        title.text = "Settings"
        title.textSize = 26f
        title.setTextColor(Color.WHITE)
        title.setTypeface(title.typeface, Typeface.BOLD)
        col.addView(title)

        // Orientation
        col.addView(header("ORIENTATION"))
        val group = RadioGroup(this)
        val labels = listOf("Auto (follow device rotation)", "Portrait", "Landscape")
        labels.forEachIndexed { i, l ->
            val rb = RadioButton(this)
            rb.id = 100 + i
            rb.text = l
            rb.textSize = 16f
            rb.setTextColor(Color.WHITE)
            rb.isChecked = Prefs.orientation(this) == i
            group.addView(rb)
        }
        group.setOnCheckedChangeListener { _, id ->
            Prefs.setOrientation(this, id - 100)
            Prefs.apply(this)
        }
        col.addView(group)
        col.addView(note("Applies to the whole app, including opened pages."))

        // Display
        col.addView(header("DISPLAY"))
        col.addView(
            toggle(
                "Hide status bar in portrait too",
                "The status bar is always hidden in landscape.",
                "hideStatusPortrait", Prefs.hideStatusPortrait(this)
            )
        )
        col.addView(
            toggle(
                "Keep screen on while viewing",
                "Stops the screen from timing out during a long page or test.",
                "keepOn", Prefs.keepOn(this)
            )
        )

        // Startup
        col.addView(header("STARTUP"))
        col.addView(
            toggle(
                "Open last file on launch",
                "Turn off to always start on the home screen.",
                "autoOpen", Prefs.autoOpen(this)
            )
        )

        // Data
        col.addView(header("RECENT FILES"))
        val clear = Button(this)
        clear.text = "Clear recent files (keeps starred)"
        clear.setOnClickListener {
            AlertDialog.Builder(this)
                .setMessage("Remove all non-starred files from the recent list?")
                .setPositiveButton("Clear") { _, _ ->
                    Store.clearUnstarred(this)
                    Toast.makeText(this, "Recent files cleared", Toast.LENGTH_SHORT).show()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
        col.addView(clear, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        col.addView(note("Files themselves are never deleted, only removed from this list."))

        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.parseColor("#121212"))
        scroll.addView(col)
        setContentView(scroll)
    }
}
