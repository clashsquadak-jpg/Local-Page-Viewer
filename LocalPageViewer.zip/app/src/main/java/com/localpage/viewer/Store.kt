package com.localpage.viewer

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

data class Recent(val uri: String, val name: String, val time: Long, val starred: Boolean)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("recent", Context.MODE_PRIVATE)

    fun recents(c: Context): List<Recent> {
        return try {
            val a = JSONArray(prefs(c).getString("list", "[]"))
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Recent(
                    o.getString("uri"), o.getString("name"),
                    o.getLong("time"), o.optBoolean("starred", false)
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(c: Context, list: List<Recent>) {
        val a = JSONArray()
        list.forEach {
            a.put(
                JSONObject().put("uri", it.uri).put("name", it.name)
                    .put("time", it.time).put("starred", it.starred)
            )
        }
        prefs(c).edit().putString("list", a.toString()).apply()
    }

    // Starred files are never trimmed; other files keep the 30 most recent.
    private fun trim(c: Context, l: List<Recent>): List<Recent> {
        val starred = l.filter { it.starred }
        val rest = l.filter { !it.starred }
        rest.drop(30).forEach { release(c, it.uri) }
        return (starred + rest.take(30)).sortedByDescending { it.time }
    }

    fun touch(c: Context, uri: String, name: String, time: Long = System.currentTimeMillis()) {
        val all = recents(c)
        val old = all.firstOrNull { it.uri == uri }
        val r = Recent(uri, name, time, old?.starred ?: false)
        save(c, trim(c, listOf(r) + all.filter { it.uri != uri }))
    }

    fun isStarred(c: Context, uri: String) = recents(c).any { it.uri == uri && it.starred }

    fun toggleStar(c: Context, uri: String) {
        save(c, recents(c).map { if (it.uri == uri) it.copy(starred = !it.starred) else it })
    }

    fun remove(c: Context, uri: String) {
        save(c, recents(c).filter { it.uri != uri })
        release(c, uri)
    }

    fun clearUnstarred(c: Context) {
        val all = recents(c)
        all.filter { !it.starred }.forEach { release(c, it.uri) }
        save(c, all.filter { it.starred })
    }

    private fun release(c: Context, uri: String) {
        try {
            c.contentResolver.releasePersistableUriPermission(
                Uri.parse(uri), Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (e: Exception) {
        }
    }

    fun displayName(c: Context, uri: Uri): String {
        try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) {
                    val n = it.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: "page.html"
    }
}
