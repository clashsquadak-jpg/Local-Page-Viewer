package com.localpage.viewer

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import org.json.JSONArray
import org.json.JSONObject

data class Recent(val uri: String, val name: String, val time: Long)

object Store {
    private fun prefs(c: Context) = c.getSharedPreferences("recent", Context.MODE_PRIVATE)

    fun recents(c: Context): List<Recent> {
        return try {
            val a = JSONArray(prefs(c).getString("list", "[]"))
            (0 until a.length()).map {
                val o = a.getJSONObject(it)
                Recent(o.getString("uri"), o.getString("name"), o.getLong("time"))
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun save(c: Context, list: List<Recent>) {
        val a = JSONArray()
        list.forEach {
            a.put(JSONObject().put("uri", it.uri).put("name", it.name).put("time", it.time))
        }
        prefs(c).edit().putString("list", a.toString()).apply()
    }

    fun add(c: Context, r: Recent) {
        save(c, (listOf(r) + recents(c).filter { it.uri != r.uri }).take(20))
    }

    fun remove(c: Context, uri: String) {
        save(c, recents(c).filter { it.uri != uri })
    }

    fun displayName(c: Context, uri: Uri): String {
        try {
            c.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
                if (it.moveToFirst()) {
                    val n = it.getString(0)
                    if (!n.isNullOrBlank()) return n
                }
            }
        } catch (e: Exception) {
        }
        return uri.lastPathSegment ?: "page.html"
    }
}
