package com.localpage.viewer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var listView: ListView
    private lateinit var emptyView: TextView
    private lateinit var search: EditText
    private lateinit var tabAll: TextView
    private lateinit var tabStar: TextView
    private var showStarred = false
    private var shown: List<Recent> = emptyList()
    private val pickCode = 1
    private val rows = RowAdapter()

    private val accent = Color.parseColor("#4C6FFF")
    private val gold = Color.parseColor("#FFC107")
    private val grey = Color.parseColor("#9E9E9E")

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(r).toFloat()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Prefs.apply(this)
        buildUi()
        if (savedInstanceState == null) {
            val data = intent?.data
            if (intent?.action == Intent.ACTION_VIEW && data != null) {
                openViewer(data)
            } else if (Prefs.autoOpen(this)) {
                Store.recents(this).firstOrNull()?.let { openViewer(Uri.parse(it.uri)) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val data = intent.data
        if (intent.action == Intent.ACTION_VIEW && data != null) openViewer(data)
    }

    override fun onResume() {
        super.onResume()
        Prefs.apply(this)
        refresh()
    }

    private fun buildUi() {
        val frame = FrameLayout(this)
        frame.setBackgroundColor(Color.parseColor("#121212"))

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.setPadding(dp(16), dp(12), dp(16), 0)

        // Header
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        val titleView = TextView(this)
        titleView.text = "Local Pages"
        titleView.textSize = 26f
        titleView.setTextColor(Color.WHITE)
        titleView.setTypeface(titleView.typeface, Typeface.BOLD)
        header.addView(titleView, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        val gear = TextView(this)
        gear.text = "\u2699"
        gear.textSize = 26f
        gear.setTextColor(Color.parseColor("#BDBDBD"))
        gear.setPadding(dp(12), dp(8), dp(4), dp(8))
        gear.setOnClickListener { startActivity(Intent(this, SettingsActivity::class.java)) }
        header.addView(gear)
        col.addView(header)

        // Search
        search = EditText(this)
        search.hint = "Search files"
        search.setHintTextColor(Color.parseColor("#757575"))
        search.setTextColor(Color.WHITE)
        search.textSize = 15f
        search.isSingleLine = true
        search.imeOptions = EditorInfo.IME_ACTION_SEARCH
        search.setPadding(dp(16), dp(10), dp(16), dp(10))
        search.background = rounded(Color.parseColor("#1E1E1E"), 24)
        search.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { refresh() }
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        })
        val sp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sp.topMargin = dp(12)
        col.addView(search, sp)

        // Tabs
        tabAll = chip("All") { showStarred = false; refresh() }
        tabStar = chip("\u2605 Starred") { showStarred = true; refresh() }
        val tabs = LinearLayout(this)
        tabs.orientation = LinearLayout.HORIZONTAL
        tabs.addView(tabAll)
        val tp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tp.leftMargin = dp(8)
        tabs.addView(tabStar, tp)
        val tabsP = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tabsP.topMargin = dp(12)
        tabsP.bottomMargin = dp(4)
        col.addView(tabs, tabsP)

        // List
        val listFrame = FrameLayout(this)
        listView = ListView(this)
        listView.divider = null
        listView.clipToPadding = false
        listView.setPadding(0, 0, 0, dp(96))
        listView.adapter = rows
        listView.setOnItemClickListener { _, _, pos, _ -> openViewer(Uri.parse(shown[pos].uri)) }
        listView.setOnItemLongClickListener { _, _, pos, _ -> showMenu(shown[pos]); true }
        emptyView = TextView(this)
        emptyView.setTextColor(Color.parseColor("#757575"))
        emptyView.gravity = Gravity.CENTER
        emptyView.setPadding(dp(24), 0, dp(24), dp(80))
        listFrame.addView(listView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        listFrame.addView(emptyView, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        listView.emptyView = emptyView
        col.addView(listFrame, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))

        frame.addView(col, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // Floating "Open file" button
        val fab = TextView(this)
        fab.text = "+  Open file"
        fab.textSize = 16f
        fab.setTextColor(Color.WHITE)
        fab.setTypeface(fab.typeface, Typeface.BOLD)
        fab.setPadding(dp(22), dp(16), dp(22), dp(16))
        fab.background = rounded(accent, 28)
        fab.elevation = dp(8).toFloat()
        fab.setOnClickListener { pick() }
        val fp = FrameLayout.LayoutParams(
            ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT,
            Gravity.BOTTOM or Gravity.END
        )
        fp.setMargins(0, 0, dp(20), dp(24))
        frame.addView(fab, fp)

        setContentView(frame)
    }

    private fun chip(label: String, onClick: () -> Unit): TextView {
        val t = TextView(this)
        t.text = label
        t.textSize = 14f
        t.setPadding(dp(16), dp(8), dp(16), dp(8))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun styleChip(t: TextView, selected: Boolean) {
        t.background = rounded(if (selected) accent else Color.parseColor("#2A2A2A"), 20)
        t.setTextColor(if (selected) Color.WHITE else Color.parseColor("#BDBDBD"))
    }

    private fun refresh() {
        if (!::listView.isInitialized) return
        val q = search.text.toString().trim().lowercase()
        shown = Store.recents(this).filter {
            (!showStarred || it.starred) && (q.isEmpty() || it.name.lowercase().contains(q))
        }
        rows.notifyDataSetChanged()
        emptyView.text = when {
            q.isNotEmpty() -> "No matching files"
            showStarred -> "No starred files yet.\nTap \u2606 next to a file to star it."
            else -> "No files yet.\nTap \u201cOpen file\u201d to pick an HTML file."
        }
        styleChip(tabAll, !showStarred)
        styleChip(tabStar, showStarred)
    }

    private fun shortName(n: String) = n.removeSuffix(".html").removeSuffix(".htm")

    private fun ago(t: Long): String {
        val m = (System.currentTimeMillis() - t) / 60000
        return when {
            m < 1 -> "just now"
            m < 60 -> "$m min ago"
            m < 1440 -> "${m / 60} h ago"
            m < 10080 -> "${m / 1440} d ago"
            else -> java.text.DateFormat.getDateInstance().format(java.util.Date(t))
        }
    }

    private fun showMenu(r: Recent) {
        val starLabel = if (r.starred) "Remove star" else "Add star"
        AlertDialog.Builder(this)
            .setTitle(shortName(r.name))
            .setItems(arrayOf("Open", starLabel, "Remove from list")) { _, which ->
                when (which) {
                    0 -> openViewer(Uri.parse(r.uri))
                    1 -> { Store.toggleStar(this, r.uri); refresh() }
                    2 -> { Store.remove(this, r.uri); refresh() }
                }
            }
            .show()
    }

    inner class RowAdapter : BaseAdapter() {
        override fun getCount() = shown.size
        override fun getItem(position: Int): Any = shown[position]
        override fun getItemId(position: Int) = position.toLong()

        private fun buildRow(): LinearLayout {
            val row = LinearLayout(this@MainActivity)
            row.orientation = LinearLayout.HORIZONTAL
            row.gravity = Gravity.CENTER_VERTICAL
            row.setPadding(dp(4), dp(10), dp(8), dp(10))

            val star = TextView(this@MainActivity)
            star.textSize = 26f
            star.gravity = Gravity.CENTER
            row.addView(star, LinearLayout.LayoutParams(dp(48), ViewGroup.LayoutParams.WRAP_CONTENT))

            val info = LinearLayout(this@MainActivity)
            info.orientation = LinearLayout.VERTICAL
            val name = TextView(this@MainActivity)
            name.textSize = 16f
            name.setTextColor(Color.WHITE)
            name.isSingleLine = true
            name.ellipsize = TextUtils.TruncateAt.END
            val sub = TextView(this@MainActivity)
            sub.textSize = 12f
            sub.setTextColor(grey)
            info.addView(name)
            info.addView(sub)
            row.addView(info, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            return row
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val r = shown[position]
            val row = (convertView as? LinearLayout) ?: buildRow()
            val star = row.getChildAt(0) as TextView
            val info = row.getChildAt(1) as LinearLayout
            (info.getChildAt(0) as TextView).text = shortName(r.name)
            (info.getChildAt(1) as TextView).text = "Opened " + ago(r.time)
            star.text = if (r.starred) "\u2605" else "\u2606"
            star.setTextColor(if (r.starred) gold else grey)
            star.setOnClickListener {
                Store.toggleStar(this@MainActivity, r.uri)
                refresh()
            }
            return row
        }
    }

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
        i.addCategory(Intent.CATEGORY_OPENABLE)
        i.type = "*/*"
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        i.addFlags(
            Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
        )
        startActivityForResult(i, pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != RESULT_OK || data == null) return

        val uris = mutableListOf<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        }
        if (uris.isEmpty()) data.data?.let { uris.add(it) }
        if (uris.isEmpty()) return

        uris.forEach {
            try {
                contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
        }
        if (uris.size == 1) {
            openViewer(uris[0])
        } else {
            val now = System.currentTimeMillis()
            uris.forEachIndexed { i, u ->
                Store.touch(this, u.toString(), Store.displayName(this, u), now - i)
            }
            Toast.makeText(this, "${uris.size} files added", Toast.LENGTH_SHORT).show()
            refresh()
        }
    }

    private fun openViewer(uri: Uri) {
        startActivity(
            Intent(this, ViewerActivity::class.java)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
