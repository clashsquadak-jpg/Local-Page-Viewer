package com.localpage.viewer

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class MainActivity : Activity() {

    private lateinit var listView: ListView
    private var items: List<Recent> = emptyList()
    private val pickCode = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        if (savedInstanceState == null) {
            val data = intent?.data
            if (intent?.action == Intent.ACTION_VIEW && data != null) {
                openViewer(data)
            } else {
                Store.recents(this).firstOrNull()?.let { openViewer(Uri.parse(it.uri)) }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val data = intent.data
        if (intent.action == Intent.ACTION_VIEW && data != null) openViewer(data)
    }

    override fun onResume() {
        super.onResume()
        items = Store.recents(this)
        listView.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_1, items.map { it.name }
        )
    }

    private fun buildUi() {
        val d = resources.displayMetrics.density
        fun px(v: Int) = (v * d).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#121212"))
            setPadding(px(20), px(20), px(20), px(20))
            fitsSystemWindows = true
        }
        root.addView(TextView(this).apply {
            text = "Local Pages"
            textSize = 26f
            setTextColor(Color.WHITE)
            setPadding(0, px(8), 0, px(16))
        })
        root.addView(Button(this).apply {
            text = "Open HTML file"
            setOnClickListener { pick() }
        })
        root.addView(TextView(this).apply {
            text = "Recent (long-press to remove)"
            textSize = 14f
            setTextColor(Color.parseColor("#9E9E9E"))
            setPadding(0, px(24), 0, px(8))
        })
        val empty = TextView(this).apply {
            text = "No files opened yet"
            setTextColor(Color.parseColor("#757575"))
            gravity = Gravity.CENTER
        }
        listView = ListView(this).apply {
            setOnItemClickListener { _, _, pos, _ -> openViewer(Uri.parse(items[pos].uri)) }
            setOnItemLongClickListener { _, _, pos, _ ->
                AlertDialog.Builder(this@MainActivity)
                    .setMessage("Remove \"${items[pos].name}\" from recent?")
                    .setPositiveButton("Remove") { _, _ ->
                        Store.remove(this@MainActivity, items[pos].uri)
                        onResume()
                    }
                    .setNegativeButton("Cancel", null)
                    .show()
                true
            }
        }
        root.addView(listView, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        root.addView(empty, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, px(80)))
        listView.emptyView = empty
        setContentView(root)
    }

    private fun pick() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            addFlags(
                Intent.FLAG_GRANT_READ_URI_PERMISSION or
                    Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION
            )
        }
        startActivityForResult(i, pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == pickCode && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            try {
                contentResolver.takePersistableUriPermission(
                    uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                )
            } catch (e: Exception) {
            }
            openViewer(uri)
        }
    }

    private fun openViewer(uri: Uri) {
        startActivity(
            Intent(this, ViewerActivity::class.java)
                .setData(uri)
                .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        )
    }
}
